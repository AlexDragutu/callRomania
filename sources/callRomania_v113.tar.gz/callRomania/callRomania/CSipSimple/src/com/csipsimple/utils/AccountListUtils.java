/**
 * Copyright (C) 2010-2012 Regis Montoya (aka r3gis - www.r3gis.fr)
 * This file is part of CSipSimple.
 *
 *  CSipSimple is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *  If you own a pjsip commercial license you can also redistribute it
 *  and/or modify it under the terms of the GNU Lesser General Public License
 *  as an android library.
 *
 *  CSipSimple is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with CSipSimple.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.csipsimple.utils;

import android.content.ContentUris;
import android.content.Context;
import android.content.res.Resources;
import android.database.Cursor;
import android.os.Handler;
import android.text.TextUtils;
import android.widget.Toast;

import ro.callromania.R;
import com.csipsimple.api.SipCallSession;
import com.csipsimple.api.SipManager;
import com.csipsimple.api.SipProfile;
import com.csipsimple.api.SipProfileState;


public class AccountListUtils {

	public static final class AccountStatusDisplay {
		public String statusLabel;
		public int statusColor;
		public int checkBoxIndicator;
		public boolean availableForCalls;
	}


	private static final String THIS_FILE = "AccountListUtils";
	
	static Toast toasty = null; 
	
	static void showToastMessage(final Context ctx, final String message)
	{
		Handler h = new Handler(ctx.getMainLooper());
		h.post(new Runnable() 
		{			
			public void run() 
			{
				try
				{
					if (toasty != null)
						toasty.cancel();
					toasty = Toast.makeText(ctx, message, Toast.LENGTH_SHORT);
					toasty.show();
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
			}
		});
	}
	
	
	public static AccountStatusDisplay getAccountDisplay(Context context, long accountId) {
		AccountStatusDisplay accountDisplay = new AccountStatusDisplay();
		accountDisplay.statusLabel = context.getString(R.string.acct_inactive);
		final Resources resources = context.getResources();
		accountDisplay.statusColor = resources.getColor(R.color.account_inactive); 
		accountDisplay.checkBoxIndicator = R.drawable.ic_indicator_yellow;
		accountDisplay.availableForCalls = false;
		

		SipProfileState accountInfo = null;
		if(accountId < 0) {return accountDisplay;}
		try {
            Cursor c = context.getContentResolver().query(ContentUris.withAppendedId(SipProfile.ACCOUNT_STATUS_ID_URI_BASE, accountId), 
            		null, null, null, null);
    		if (c != null) {
    			try {
    				if(c.getCount() > 0) {
    					c.moveToFirst();
    					accountInfo = new SipProfileState(c);
    				}
    			} catch (Exception e) {
    				Log.e(THIS_FILE, "Error on looping over sip profiles states", e);
    			} finally {
    				c.close();
    			}
    		}
		}catch(Exception e) {
		    Log.e(THIS_FILE, "Failed account id " + accountId);
		}
		
		if (accountInfo != null && accountInfo.isActive()) {
			if (accountInfo.getAddedStatus() >= SipManager.SUCCESS) {

				accountDisplay.statusLabel = context.getString(R.string.acct_unregistered);
				accountDisplay.statusColor = resources.getColor(R.color.account_unregistered);
				accountDisplay.checkBoxIndicator = R.drawable.ic_indicator_yellow;
				if( TextUtils.isEmpty( accountInfo.getRegUri()) ) {
					// Green
					accountDisplay.statusColor = resources.getColor(R.color.account_valid);
					accountDisplay.checkBoxIndicator = R.drawable.ic_indicator_on;
					accountDisplay.statusLabel = context.getString(R.string.acct_registered);
					accountDisplay.availableForCalls = true;
					
					showToastMessage(context, context.getString(R.string.acct_registered));
				}else if (accountInfo.isAddedToStack()) {
					String pjStat = accountInfo.getStatusText();	// Used only on error status message
					int statusCode = accountInfo.getStatusCode();
					if (statusCode == SipCallSession.StatusCode.OK) {
						// Log.d(THIS_FILE,
						// "Now account "+account.display_name+" has expires "+accountInfo.getExpires());
						if (accountInfo.getExpires() > 0) {
							// Green
							accountDisplay.statusColor = resources.getColor(R.color.account_valid);
							accountDisplay.checkBoxIndicator = R.drawable.ic_indicator_on;
							accountDisplay.statusLabel = context.getString(R.string.acct_registered);
							accountDisplay.availableForCalls = true;
							showToastMessage(context, context.getString(R.string.acct_registered));
						} else {
							// Yellow unregistered
							accountDisplay.statusColor = resources.getColor(R.color.account_unregistered);
							accountDisplay.checkBoxIndicator = R.drawable.ic_indicator_yellow;
							accountDisplay.statusLabel = context.getString(R.string.acct_unregistered);
						}
					} else if(statusCode != -1 ){
						if (statusCode == SipCallSession.StatusCode.PROGRESS || statusCode == SipCallSession.StatusCode.TRYING) {
							// Yellow progressing ...
							accountDisplay.statusColor = resources.getColor(R.color.account_unregistered);
							accountDisplay.checkBoxIndicator = R.drawable.ic_indicator_yellow;
							accountDisplay.statusLabel = context.getString(R.string.acct_registering);
							showToastMessage(context, context.getString(R.string.acct_registering));
						} else {
							//TODO : treat 403 with special message
							// Red : error
							accountDisplay.statusColor = resources.getColor(R.color.account_error);
							accountDisplay.checkBoxIndicator = R.drawable.ic_indicator_red;
							accountDisplay.statusLabel = context.getString(R.string.acct_regerror) + " - " + pjStat;	// Why can't ' - ' be in resource?
							showToastMessage(context, context.getString(R.string.acct_regerror));
						}
					}else {
						// Account is currently registering (added to pjsua but not replies yet from pjsua registration)
						accountDisplay.statusColor = resources.getColor(R.color.account_inactive);
						accountDisplay.checkBoxIndicator = R.drawable.ic_indicator_yellow;
						accountDisplay.statusLabel = context.getString(R.string.acct_registering);
						showToastMessage(context, context.getString(R.string.acct_registering));
					}
				}
			} else {
				if(accountInfo.isAddedToStack()) {
					accountDisplay.statusLabel = context.getString(R.string.acct_regfailed);
					accountDisplay.statusColor = resources.getColor(R.color.account_error);
					showToastMessage(context, context.getString(R.string.acct_regfailed));
				}else {
					accountDisplay.statusColor = resources.getColor(R.color.account_inactive);
					accountDisplay.checkBoxIndicator = R.drawable.ic_indicator_yellow;
					accountDisplay.statusLabel = context.getString(R.string.acct_registering);
					showToastMessage(context, context.getString(R.string.acct_registering));
					
				}
			}
		}
		return accountDisplay;
	}
	
	
	
}
